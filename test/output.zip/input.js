const helloWorld = () => {
  console.log('Hello world!');
  return 'hello from function';
}

module.exports = helloWorld;
