const helloWorld = () => {
  console.log('Hello world!');
}

helloWorld();
